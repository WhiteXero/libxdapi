# libxdapi - X岛API Python库

### API文档来源：https://github.com/TransparentLC/xdcmd
### Python 版本要求 ≥ 3.0 ，基于 Requests 库
### PyPI：https://pypi.org/project/libxdapi

### API 文档整合：https://xd.entech.link

#### 因同步问题，安装时请使用官方源。
